let posicaoTratorX;
let velocidadeTrator = 2;
// As variáveis do helicóptero foram removidas:
// let xHelicopter = 100;
// let yHelicopter = 100;
// let velocidadeMovimentoHelicoptero = 3;

function setup() {
  createCanvas(600, 400);
  noStroke(); // Remove as bordas das formas
  posicaoTratorX = -150; // Começa o trator fora da tela, à esquerda
}

function draw() {
  // Cenário: metade azul claro em cima, metade verde embaixo
  fill(0, 200, 0); // Verde vibrante para o chão
  rect(0, height / 2, width, height / 2);

  fill(135, 206, 250); // Azul Céu
  rect(0, 0, width, height / 2);

  // Sol no canto superior esquerdo
  fill(255, 200, 0); // Amarelo alaranjado
  ellipse(70, 70, 100, 100);

  // --- Desenha as Casas Melhoradas e Reposicionadas (sem a Casa 4) ---

  // Casa 1: Casa de Campo Tradicional (Marrom)
  // Posicionada mais à esquerda, com bom espaço para a próxima
  let xCasa1 = 30; // Posição X ajustada
  let yCasa1 = height / 2 - 85;
  let larguraCasa1 = 80;
  let alturaCasa1 = 85;

  fill(100, 80, 60);
  rect(xCasa1 - 5, yCasa1 + alturaCasa1, larguraCasa1 + 10, 10);

  fill(180, 120, 70);
  rect(xCasa1, yCasa1, larguraCasa1, alturaCasa1);

  fill(160, 100, 50);
  for (let y = 0; y < alturaCasa1; y += 10) {
    rect(xCasa1, yCasa1 + y, larguraCasa1, 5);
  }

  fill(130, 40, 40);
  triangle(xCasa1 - 10, yCasa1,
           xCasa1 + larguraCasa1 + 10, yCasa1,
           xCasa1 + larguraCasa1 / 2, yCasa1 - 45);
  stroke(100, 30, 30);
  for (let i = 0; i < 40; i += 10) {
      line(xCasa1 - 10 + i/2, yCasa1 + i, xCasa1 + larguraCasa1 + 10 - i/2, yCasa1 + i);
  }
  noStroke();

  fill(100, 30, 30);
  rect(xCasa1 - 10, yCasa1 - 5, larguraCasa1 + 20, 5);

  fill(100, 40, 40);
  rect(xCasa1 + larguraCasa1 - 25, yCasa1 - 65, 18, 35);

  fill(80, 50, 20);
  rect(xCasa1 + 30, yCasa1 + alturaCasa1 - 45, 25, 45);
  fill(50);
  ellipse(xCasa1 + 30 + 5, yCasa1 + alturaCasa1 - 45 + 20, 4, 4);

  fill(150, 150, 150);
  rect(xCasa1 + 25, yCasa1 + alturaCasa1, 35, 5);

  fill(170, 200, 255);
  rect(xCasa1 + 10, yCasa1 + 15, 28, 28);
  rect(xCasa1 + larguraCasa1 - 40, yCasa1 + 15, 28, 28);
  fill(50, 50, 50, 150);
  rect(xCasa1 + 10 + 12, yCasa1 + 15, 3, 28);
  rect(xCasa1 + 10, yCasa1 + 15 + 12, 28, 3);
  rect(xCasa1 + larguraCasa1 - 40 + 12, yCasa1 + 15, 3, 28);
  rect(xCasa1 + larguraCasa1 - 40, yCasa1 + 15 + 12, 28, 3);

  fill(80, 50, 20);
  rect(xCasa1 + 10, yCasa1 + 15 + 28, 28, 8);
  fill(34, 139, 34);
  ellipse(xCasa1 + 15, yCasa1 + 15 + 28, 10, 8);
  ellipse(xCasa1 + 25, yCasa1 + 15 + 28, 10, 8);
  ellipse(xCasa1 + 35, yCasa1 + 15 + 28, 10, 8);


  // Casa 2: Celeiro ou Casa Maior (Cinza)
  // Posicionada à direita da primeira, com um bom espaço adequado
  let xCasa2 = xCasa1 + larguraCasa1 + 40;
  let yCasa2 = height / 2 - 95;
  let larguraCasa2 = 100;
  let alturaCasa2 = 70;

  fill(130, 130, 130);
  rect(xCasa2 - 5, yCasa2 + alturaCasa2, larguraCasa2 + 10, 10);

  fill(150, 150, 150);
  rect(xCasa2, yCasa2, larguraCasa2, alturaCasa2);

  fill(100, 100, 100);
  rect(xCasa2 + 5, yCasa2, 5, alturaCasa2);
  rect(xCasa2 + larguraCasa2 - 10, yCasa2, 5, alturaCasa2);
  rect(xCasa2 + larguraCasa2 / 2 - 2.5, yCasa2, 5, alturaCasa2);
  rect(xCasa2, yCasa2 + 10, larguraCasa2, 5);
  rect(xCasa2, yCasa2 + alturaCasa2 - 15, larguraCasa2, 5);

  fill(80, 80, 80);
  triangle(xCasa2 - 10, yCasa2,
           xCasa2 + larguraCasa2 / 2, yCasa2 - 40,
           xCasa2 + larguraCasa2 + 10, yCasa2);
  fill(60, 60, 60);
  rect(xCasa2 - 10, yCasa2 - 5, larguraCasa2 + 20, 5);

  fill(90, 60, 30);
  rect(xCasa2 + 35, yCasa2 + alturaCasa2 - 40, 30, 40);
  fill(70, 40, 10);
  rect(xCasa2 + 35 + 5, yCasa2 + alturaCasa2 - 40, 2, 40);
  rect(xCasa2 + 35 + 23, yCasa2 + alturaCasa2 - 40, 2, 40);
  rect(xCasa2 + 35, yCasa2 + alturaCasa2 - 40 + 10, 30, 2);

  fill(170, 200, 255);
  rect(xCasa2 + 10, yCasa2 + 10, 20, 20);
  rect(xCasa2 + larguraCasa2 - 30, yCasa2 + 10, 20, 20);

  let xEscada = xCasa2 + 30;
  let yEscadaBase = yCasa2 + alturaCasa2;

  fill(120, 120, 120);
  rect(xEscada, yEscadaBase, 40, 10);
  rect(xEscada - 5, yEscadaBase + 10, 50, 10);
  rect(xEscada - 10, yEscadaBase + 20, 60, 10);

  fill(50, 50, 50);
  rect(xEscada, yEscadaBase - 20, 3, 30);
  rect(xEscada + 37, yEscadaBase - 20, 3, 30);
  rect(xEscada, yEscadaBase - 20, 40, 3);
  rect(xEscada + 10, yEscadaBase - 10, 3, 20);
  rect(xEscada + 27, yEscadaBase - 10, 3, 20);


  // Casa 3: Casa Pequena e Colorida (Rosa)
  // Posicionada à direita da casa cinza, com um bom intervalo
  let xCasa3 = xCasa2 + larguraCasa2 + 40;
  let yCasa3 = height / 2 - 75;
  let larguraCasa3 = 70;
  let alturaCasa3 = 75;

  fill(180, 100, 100);
  rect(xCasa3 - 5, yCasa3 + alturaCasa3, larguraCasa3 + 10, 10);

  fill(255, 160, 160);
  rect(xCasa3, yCasa3, larguraCasa3, alturaCasa3);

  fill(240, 140, 140);
  for (let i = 0; i < larguraCasa3; i += 15) {
      for (let j = 0; j < alturaCasa3; j += 15) {
          if (i % 30 === 0) {
            rect(xCasa3 + i, yCasa3 + j, 10, 10);
          } else {
            rect(xCasa3 + i, yCasa3 + j + 7.5, 10, 10);
          }
      }
  }

  fill(180, 80, 80);
  triangle(xCasa3 - 8, yCasa3,
           xCasa3 + larguraCasa3 + 8, yCasa3,
           xCasa3 + larguraCasa3 / 2, yCasa3 - 35);

  fill(150, 70, 70);
  for (let y = 0; y < 30; y += 10) {
      triangle(xCasa3 - 8 + y/2, yCasa3 + y,
               xCasa3 + larguraCasa3 + 8 - y/2, yCasa3 + y,
               xCasa3 + larguraCasa3 / 2, yCasa3 - 35 + y);
  }

  fill(80, 50, 20);
  rect(xCasa3 + 25, yCasa3 + alturaCasa3 - 30, 20, 30);
  fill(60, 30, 0);
  rect(xCasa3 + 25, yCasa3 + alturaCasa3 - 30 + 10, 20, 2);

  fill(170, 200, 255);
  rect(xCasa3 + 10, yCasa3 + 10, 18, 18);
  rect(xCasa3 + larguraCasa3 - 28, yCasa3 + 10, 18, 18);
  fill(50, 50, 50);
  rect(xCasa3 + 20, yCasa3 + 10, 2, 20);
  rect(xCasa3 + larguraCasa3 - 20, yCasa3 + 10, 2, 20);


  // A Casa 4 (Casa de Madeira Rústica) foi removida.
  // Se quiser, podemos reajustar as posições das casas restantes
  // para preencher o espaço ou criar um novo arranjo.


  // Casa 5: Casa Simples (agora 'Casa 4' na linha, mas mantém variáveis para clareza)
  // Posicionada bem à direita, para completar a linha de casas
  let xCasa5 = xCasa3 + larguraCasa3 + 40; // Posição X ajustada
  let yCasa5 = height / 2 - 60;
  let larguraCasa5 = 60;
  let alturaCasa5 = 60;

  fill(170, 170, 170);
  rect(xCasa5 - 3, yCasa5 + alturaCasa5, larguraCasa5 + 6, 8);

  fill(220, 220, 220);
  rect(xCasa5, yCasa5, larguraCasa5, alturaCasa5);

  fill(120, 60, 60);
  triangle(xCasa5 - 5, yCasa5,
           xCasa5 + larguraCasa5 + 5, yCasa5,
           xCasa5 + larguraCasa5 / 2, yCasa5 - 30);
  stroke(90, 40, 40);
  for (let i = 0; i < 20; i += 7) {
      line(xCasa5 - 5 + i/2, yCasa5 + i, xCasa5 + larguraCasa5 + 5 - i/2, yCasa5 + i);
  }
  noStroke();

  fill(100, 100, 100);
  rect(xCasa5 + larguraCasa5 / 2 - 10, yCasa5 + alturaCasa5 - 30, 20, 30);

  fill(170, 200, 255);
  rect(xCasa5 + 10, yCasa5 + 10, 15, 15);
  fill(50, 50, 50);
  rect(xCasa5 + 10 + 6, yCasa5 + 10, 2, 15);
  rect(xCasa5 + 10, yCasa5 + 10 + 6, 15, 2);


  // --- Desenha a Rua ---
  fill(80, 80, 80); // Cinza escuro para a rua
  rect(0, height / 2 + 50, width, 50);

  // Linhas da estrada
  fill(255, 255, 0); // Amarelo para as linhas
  for (let i = 20; i < width; i += 80) {
    rect(i, height / 2 + 70, 40, 5);
  }


  // --- Desenha a Plantação de Milho Melhorada e Parada ---
  let plantacaoY = height - 30; // Base da plantação

  for (let i = 0; i < width + 70; i += 30) {
    push();
    translate(i, plantacaoY);

    // Caule principal
    let stemHeight = random(40, 60);
    let stemWidth = random(4, 6);
    fill(40, 120, 40); // Verde mais escuro para o caule
    rect(0, 0, stemWidth, -stemHeight);

    // Folhas
    fill(60, 150, 60); // Verde vibrante para as folhas
    // Folha inferior esquerda
    push();
    translate(0, -stemHeight * 0.3);
    rotate(radians(random(-35, -15)));
    rect(0, 0, random(25, 35), random(3, 5));
    pop();
    // Folha inferior direita
    push();
    translate(stemWidth, -stemHeight * 0.4);
    rotate(radians(random(15, 35)));
    rect(0, 0, random(25, 35), random(3, 5));
    pop();
    // Folha superior esquerda
    push();
    translate(0, -stemHeight * 0.6);
    rotate(radians(random(-25, -5)));
    rect(0, 0, random(15, 25), random(2, 4));
    pop();
    // Folha superior direita
    push();
    translate(stemWidth, -stemHeight * 0.7);
    rotate(radians(random(5, 25)));
    rect(0, 0, random(15, 25), random(2, 4));
    pop();

    // Espiga de milho (opcional, nem todas as plantas terão)
    if (random(1) > 0.4) { // 60% de chance de ter espiga
        fill(255, 200, 0); // Amarelo para a espiga
        ellipse(stemWidth / 2, -stemHeight * random(0.4, 0.7), random(8, 12), random(15, 25));
        fill(150, 100, 0); // Marrom para as "barbas"
        rect(stemWidth / 2 - 1, -stemHeight * random(0.5, 0.8) - 15, 2, 10);
    }

    pop();
  }

  // --- O código do helicóptero e seu controle de teclado foram removidos aqui ---


  // --- Desenha e move o Trator Roxo ---
  push();
  translate(posicaoTratorX, height - 80);

  // Corpo Principal
  fill(128, 0, 128); // Roxo puro para o corpo
  rect(0, 0, 100, 45);

  // Capô/Motor
  fill(150, 0, 150); // Um tom de roxo um pouco mais claro para o capô
  rect(90, -10, 40, 30);

  // Cabine
  fill(100, 0, 100); // Roxo mais escuro para a cabine
  rect(40, -50, 60, 50);

  // Chaminé/Escapamento
  fill(80); // Cinza escuro para a chaminé
  rect(100, -65, 10, 20);
  ellipse(105, -65, 15, 10);

  // Rodas
  fill(50); // Cinza para o pneu
  ellipse(30, 45, 60, 60);
  fill(150); // Cinza claro para o aro
  ellipse(30, 45, 30, 30);

  fill(50); // Cinza para o pneu
  ellipse(115, 45, 40, 40);
  fill(150); // Cinza claro para o aro
  ellipse(115, 45, 20, 20);

  pop();

  // Atualiza a posição do trator
  posicaoTratorX += velocidadeTrator;

  // Reinicia o trator se ele sair da tela
  if (posicaoTratorX > width + 150) {
    posicaoTratorX = -150;
  }
}